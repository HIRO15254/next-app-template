create function login_user_data() returns user_data
    stable
    language sql
as
$$ select * from user_data where id = auth.uid() $$;

alter function login_user_data() owner to postgres;

grant execute on function login_user_data() to anon;

grant execute on function login_user_data() to authenticated;

grant execute on function login_user_data() to service_role;

