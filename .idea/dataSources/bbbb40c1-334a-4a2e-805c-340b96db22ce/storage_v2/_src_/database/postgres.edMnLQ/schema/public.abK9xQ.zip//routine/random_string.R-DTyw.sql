create function random_string(p_length integer DEFAULT 10, p_source text DEFAULT 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'::text) returns text
    language plpgsql
as
$$
DECLARE
    w_result text := '';
    w_index int := 0;
BEGIN
    -- 入力チェック
    IF p_length IS NULL or p_length < 1 or p_source IS NULL or p_source = '' THEN
        RETURN '';
    END IF;
   
    -- 文字列生成
    FOR i IN 1..p_length LOOP
        w_index := floor(random() * length(p_source))::integer + 1;
        w_result := w_result || substring(p_source, w_index, 1);
    END LOOP;
    RETURN w_result;
END;
$$;

alter function random_string(integer, text) owner to postgres;

grant execute on function random_string(integer, text) to anon;

grant execute on function random_string(integer, text) to authenticated;

grant execute on function random_string(integer, text) to service_role;

